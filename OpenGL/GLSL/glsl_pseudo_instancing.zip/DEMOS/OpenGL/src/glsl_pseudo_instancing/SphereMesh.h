#ifndef SPHERE_MESH_H
#define SPHERE_MESH_H

#include "Mesh.h"

class SphereMesh : public Mesh
{
public:
  SphereMesh(int rows, int columns);
};


#endif
