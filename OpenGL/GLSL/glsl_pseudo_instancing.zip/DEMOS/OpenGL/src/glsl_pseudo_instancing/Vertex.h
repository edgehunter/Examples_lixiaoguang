#ifndef VERTEX_H
#define VERTEX_H

struct Vertex
{
  float mPosition[3];
  float mNormal[3];
  float mTextureCoord0[2];
};


#endif
