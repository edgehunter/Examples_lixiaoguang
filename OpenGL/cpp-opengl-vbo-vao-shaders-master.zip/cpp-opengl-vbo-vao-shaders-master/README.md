# cpp-opengl-vbo-vao-shaders

Usage:

```
    git submodule init
    git submodule update
    mkdir build
    cd build
    cmake ..
    make
    ./triangle
```

Tested on Linux, MacOS and Windows.
