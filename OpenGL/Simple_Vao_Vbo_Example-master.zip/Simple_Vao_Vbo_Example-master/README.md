# Simple_Vao_Vbo_Example

This has 3 approaches to create simple trianle, to clarify about buffers.

1. VAO and 2 VBO using oF API
2. Interleaved buffer using oF API
3. Interleaved buffer using raw OpenGL API

![ss](https://github.com/yumataesu/Simple_Vao_Vbo_Example/blob/master/image.gif)
