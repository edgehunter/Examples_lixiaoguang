#include "accept.hpp"

namespace async { 
	namespace service
	{
		std::_Ph<2> _Socket;
		std::_Ph<3> _Address;
	}

}