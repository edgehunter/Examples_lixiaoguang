#ifndef __ASYNC_BASIC_HPP
#define __ASYNC_BASIC_HPP



#include <winsock2.h>
#include <mswsock.h>
#include <WS2tcpip.h>
#include <windows.h>


#pragma comment(lib, "ws2_32")
#pragma comment(lib, "mswsock")

#endif