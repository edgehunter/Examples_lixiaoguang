#include "async_result.hpp"

#include <mutex>

namespace async { namespace service {


	std::_Ph<1> _Error;
	std::_Ph<2> _Size;


}}