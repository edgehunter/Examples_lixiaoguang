iocpframework
=============

iocp async framework

Copyright (c) 2011, Chen Yu. All rights reserved.

Use of this source code is governed by a BSD-style license that can be found in the License file.

iocpframework是一个用现代C++开发的异步库，支持network、file、等异步IO或者非IO操作。目前仅支持windows，计划加入linux平台支持。
