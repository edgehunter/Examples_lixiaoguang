
void svr_start(char **argv);