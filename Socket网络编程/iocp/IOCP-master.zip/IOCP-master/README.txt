You need Boost lib for compling. Please set a correct path for Boost lib in 
[Project Properties] / [C/C++] / [General] / [Additional Include Directories]

More deatils on this project are in my post.
http://young2code.wordpress.com/2009/08/16/network-programming-with-iocp-and-thread-pool-intro/
http://young2code.wordpress.com/2010/05/30/iocp-with-the-original-or-old-thread-pool-api/